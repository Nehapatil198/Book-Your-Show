import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homecarousel',
  templateUrl: './homecarousel.component.html',
  styleUrls: ['./homecarousel.component.css']
})
export class HomecarouselComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
