export class Theatre
{

    theatreid:string;
    theatrename:string;
    totalscreens:number;
    zipcode:number;


}
