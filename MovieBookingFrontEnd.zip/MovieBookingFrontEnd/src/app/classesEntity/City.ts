export class City
{

    zipcode:number;
    cityname:string;
    state:string;

}
