export class Screen
{

    screenid:string;
    totalnumberofseats:number;
    theatreid:string;

}
