import { Time } from '@angular/common';
export class payment
{

    paymentid:number;
    amount:number;
    timestamp:Date;
    paymentstatus:string;    //enum
    bookingid:number;

}
