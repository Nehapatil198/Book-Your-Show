AddMovie

{
    "title" : "Batman",
    "description" : "This is Super hero Movie" ,
    "duration" : "2021-02-01T02:34:56.123+05:30" ,
    "rating" : 8.9,
    "language" : "English" ,
    "type" : "Action"
}

addshow :
{
    "date": "2021-02-25TT02:34:56.123+05:30"
    "time": "2021-02-01T02:34:56.123+05:30",
    "screenid":1 ,
    "movieid":1
}




insert into user (userid,email, phone, username, password) values (100,"a@b.c","9988776655","user1","user123");
insert into user (userid,email, phone, username, password) values (200,"b@b.c","9988776655","user2","user123");
insert into user (userid,email, phone, username, password) values (300,"c@b.c","9988776655","user3","user123");




insert into city ( zipcode, cityname , state ) values ( 425412 , "Nandurbar" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 422003 , "Nashik" , "Maharashtra"  );
insert into city ( zipcode, cityname , state ) values ( 556644 , "Lucknow" , "Uttar Pradesh"  );

insert into city ( zipcode, cityname , state ) values ( 136118, "Kurukshetra" , "Haryana"  );
insert into city ( zipcode, cityname , state ) values ( 530068 , "Bangalore" , "Karnataka"  );
insert into city ( zipcode, cityname , state ) values ( 11096, "Noida" , " Uttar Pradesh "  );
insert into city ( zipcode, cityname , state ) values ( 403001 , "Panji" , " Goa "  );





insert into theatre ( theatreid , theatrename , totalscreens , zipcode ) values( 'T001' , "Inox" , 3 , 422003 );
insert into theatre ( theatreid , theatrename , totalscreens , zipcode ) values ( 'T002' , "Cinemax" , 2 , 422003 );
insert into theatre ( theatreid , theatrename , totalscreens , zipcode ) values ( 'T003' , "Inox" , 4 , 556644);
insert into theatre ( theatreid , theatrename , totalscreens , zipcode ) values ( 'T004' , "Miraj" , 2 , 425412 );
insert into theatre ( theatreid , theatrename , totalscreens , zipcode ) values ( 'T005' , "VijayMamta" , 5 , 422003 );



